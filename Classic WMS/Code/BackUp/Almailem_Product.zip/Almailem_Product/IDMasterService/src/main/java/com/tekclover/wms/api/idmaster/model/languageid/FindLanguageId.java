package com.tekclover.wms.api.idmaster.model.languageid;

import lombok.Data;
import java.util.List;

@Data
public class FindLanguageId {
    private List<String> languageId;
}
