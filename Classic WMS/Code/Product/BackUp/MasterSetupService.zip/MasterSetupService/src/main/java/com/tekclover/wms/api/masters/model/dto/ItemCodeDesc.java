package com.tekclover.wms.api.masters.model.dto;

import lombok.Data;

@Data
public class ItemCodeDesc {

	private String itemCode;
	private String description;
}
