package com.tekclover.wms.api.masters.model.impl;

public interface StorageBinListImpl {

    String getStorageBin();
}
