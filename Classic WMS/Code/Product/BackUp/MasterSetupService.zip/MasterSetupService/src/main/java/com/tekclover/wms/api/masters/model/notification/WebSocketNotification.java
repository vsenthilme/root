package com.tekclover.wms.api.masters.model.notification;

import lombok.Data;

@Data
public class WebSocketNotification {

	private String from;
	private String text;
}
