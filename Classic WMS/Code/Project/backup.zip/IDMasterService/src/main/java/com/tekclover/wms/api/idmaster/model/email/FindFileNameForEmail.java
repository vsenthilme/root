package com.tekclover.wms.api.idmaster.model.email;

import lombok.Data;

@Data
public class FindFileNameForEmail {

	private Long fileNameId;

	private String reportDate;
}
